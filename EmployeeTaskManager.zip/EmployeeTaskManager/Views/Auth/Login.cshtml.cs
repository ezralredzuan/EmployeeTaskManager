using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EmployeeTaskManager.Views.Auth
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
