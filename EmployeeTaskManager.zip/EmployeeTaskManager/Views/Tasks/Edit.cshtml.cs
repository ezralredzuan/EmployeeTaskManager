using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EmployeeTaskManager.Views.Tasks
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
