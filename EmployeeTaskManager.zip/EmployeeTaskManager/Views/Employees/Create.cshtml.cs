using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EmployeeTaskManager.Views.Employees
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
