﻿namespace EmployeeTaskManager.Models
{
    public class TaskAudit
    {
        public int Id { get; set; }

        // The task this audit belongs to
        public int TaskItemId { get; set; }
        public TaskItem TaskItem { get; set; }

        // The user who did the action
        public int UserId { get; set; }

        // What action: Created, Completed, Uncompleted
        public string Action { get; set; }

        public DateTime ActionDate { get; set; } = DateTime.Now;
    }
}
