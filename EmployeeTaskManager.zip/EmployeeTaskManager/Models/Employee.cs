﻿namespace EmployeeTaskManager.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }

        public string Password { get; set; }   // ADD THIS
        public bool IsActive { get; set; }
    }
}
